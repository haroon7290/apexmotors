/* Shared helpers and site-wide behaviour */

const fmtPrice = (n) => '£' + Number(n).toLocaleString('en-GB');
const fmtNumber = (n) => Number(n).toLocaleString('en-GB');

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function getVehicle(id) {
  return VEHICLES.find((v) => v.id === id);
}

function vehicleCard(v) {
  const title = `${v.year} ${v.make} ${v.model}`;
  return `
    <a class="vehicle-card reveal" href="vehicle.html?id=${encodeURIComponent(v.id)}" aria-label="View ${escapeHtml(title)}">
      <div class="vehicle-media">
        <img src="${v.images[0]}" alt="${escapeHtml(title + ' ' + v.variant)}" loading="lazy" onerror="this.onerror=null;this.src='${FALLBACK_IMG}'">
        ${v.badge ? `<span class="badge">${escapeHtml(v.badge)}</span>` : ''}
        <span class="badge dark">${v.year}</span>
      </div>
      <div class="vehicle-body">
        <h3 class="vehicle-title">${escapeHtml(title)}<small>${escapeHtml(v.variant)}</small></h3>
        <div class="vehicle-specs">
          <span>${fmtNumber(v.mileage)} miles</span>
          <span>${escapeHtml(v.fuel)}</span>
          <span>${escapeHtml(v.transmission)}</span>
          <span>${escapeHtml(v.body)}</span>
        </div>
        <div class="vehicle-footer">
          <div class="price">${fmtPrice(v.price)}<small>No admin fees</small></div>
          <span class="btn btn-outline-dark btn-sm">View details</span>
        </div>
      </div>
    </a>`;
}

function renderVehicles(container, list) {
  if (!container) return;
  container.innerHTML = list.map(vehicleCard).join('');
  observeReveals(container);
}

/* Scroll reveal */
let revealObserver;
function observeReveals(root = document) {
  if (!('IntersectionObserver' in window)) {
    root.querySelectorAll('.reveal').forEach((el) => el.classList.add('in'));
    return;
  }
  revealObserver = revealObserver || new IntersectionObserver((entries) => {
    entries.forEach((e) => {
      if (e.isIntersecting) { e.target.classList.add('in'); revealObserver.unobserve(e.target); }
    });
  }, { threshold: 0.12 });
  root.querySelectorAll('.reveal:not(.in)').forEach((el) => revealObserver.observe(el));
}

/* Open / closed indicator */
function isOpenNow() {
  const now = new Date();
  const h = now.getHours();
  return h >= DEALER.openHour && h < DEALER.closeHour;
}

/* Simple client-side form validation + submit simulation.
   Hook a backend (e.g. Formspree, Netlify Forms, or your CRM endpoint) inside submitHandler when ready. */
function bindForm(form, onSuccess) {
  if (!form) return;
  form.setAttribute('novalidate', '');
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    let valid = true;
    form.querySelectorAll('.field').forEach((field) => {
      const input = field.querySelector('input, textarea, select');
      if (!input) return;
      let ok = true;
      if (input.required && !input.value.trim()) ok = false;
      if (ok && input.type === 'email' && input.value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.value)) ok = false;
      if (ok && input.type === 'tel' && input.value && !/^[\d\s+()-]{10,}$/.test(input.value)) ok = false;
      if (ok && input.type === 'checkbox' && input.required && !input.checked) ok = false;
      field.classList.toggle('invalid', !ok);
      if (!ok) valid = false;
    });
    if (!valid) {
      const first = form.querySelector('.field.invalid input, .field.invalid textarea');
      if (first) first.focus();
      return;
    }
    const btn = form.querySelector('button[type="submit"]');
    if (btn) { btn.disabled = true; btn.textContent = 'Sending...'; }
    setTimeout(() => {
      form.reset();
      if (btn) { btn.disabled = false; btn.textContent = btn.dataset.label || 'Send enquiry'; }
      if (onSuccess) onSuccess();
    }, 700);
  });
  form.querySelectorAll('input, textarea, select').forEach((el) => {
    el.addEventListener('input', () => el.closest('.field')?.classList.remove('invalid'));
  });
}

/* Site-wide init */
document.addEventListener('DOMContentLoaded', () => {
  // Mobile nav
  const toggle = document.getElementById('navToggle');
  const nav = document.getElementById('mainNav');
  if (toggle && nav) {
    toggle.addEventListener('click', () => {
      const open = nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', String(open));
    });
    nav.querySelectorAll('a').forEach((a) => a.addEventListener('click', () => {
      nav.classList.remove('open');
      toggle.setAttribute('aria-expanded', 'false');
    }));
  }

  // Footer year
  document.querySelectorAll('[data-year]').forEach((el) => { el.textContent = new Date().getFullYear(); });

  // Open/closed badges
  document.querySelectorAll('[data-open-status]').forEach((el) => {
    const open = isOpenNow();
    el.textContent = open ? 'Open now until 7pm' : 'Closed - opens 9am';
    el.classList.toggle('closed', !open);
  });

  // Homepage: featured vehicles + hero search
  const featured = document.getElementById('featuredVehicles');
  if (featured) {
    renderVehicles(featured, VEHICLES.filter((v) => v.featured).slice(0, 6));
  }

  const heroMake = document.getElementById('heroMake');
  if (heroMake) {
    [...new Set(VEHICLES.map((v) => v.make))].sort().forEach((m) => {
      heroMake.insertAdjacentHTML('beforeend', `<option value="${escapeHtml(m)}">${escapeHtml(m)}</option>`);
    });
  }
  const heroSearch = document.getElementById('heroSearch');
  if (heroSearch) {
    heroSearch.addEventListener('submit', (e) => {
      e.preventDefault();
      const params = new URLSearchParams();
      ['make', 'body', 'maxPrice'].forEach((k) => {
        const val = heroSearch.elements[k]?.value;
        if (val) params.set(k, val);
      });
      window.location.href = 'inventory.html' + (params.toString() ? '?' + params.toString() : '');
    });
  }

  // Stock count placeholders
  document.querySelectorAll('[data-stock-count]').forEach((el) => { el.textContent = VEHICLES.length; });

  observeReveals();
});
