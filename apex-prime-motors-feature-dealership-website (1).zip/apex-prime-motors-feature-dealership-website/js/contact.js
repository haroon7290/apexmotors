/* Contact page */

document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('contactForm');
  const success = document.getElementById('contactSuccess');
  if (!form) return;

  // Populate vehicle-of-interest select from stock
  const select = form.elements.vehicle;
  if (select) {
    VEHICLES.forEach((v) => {
      select.insertAdjacentHTML('beforeend', `<option value="${escapeHtml(v.id)}">${escapeHtml(`${v.year} ${v.make} ${v.model} ${v.variant} - ${fmtPrice(v.price)}`)}</option>`);
    });
    const pre = new URLSearchParams(window.location.search).get('vehicle');
    if (pre) select.value = pre;
  }

  bindForm(form, () => {
    success?.classList.add('show');
    success?.scrollIntoView({ behavior: 'smooth', block: 'center' });
  });
});
