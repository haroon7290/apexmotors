/* Apex Prime Motors - dealer details and vehicle stock */

const DEALER = {
  name: 'Apex Prime Motors Ltd',
  shortName: 'Apex Prime Motors',
  address: '04 Aldborough Spur, Slough, SL1 3EN',
  addressLines: ['04 Aldborough Spur', 'Slough', 'SL1 3EN'],
  phone: '07517 146120',
  phoneHref: 'tel:07517146120',
  whatsapp: 'https://wa.me/447517146120',
  email: 'sales@apexprimemotors.co.uk',
  hours: 'Monday - Sunday, 9:00am - 7:00pm',
  openHour: 9,
  closeHour: 19,
  mapEmbed: 'https://www.google.com/maps?q=04+Aldborough+Spur,+Slough,+SL1+3EN&output=embed',
  mapLink: 'https://www.google.com/maps/search/?api=1&query=04+Aldborough+Spur+Slough+SL1+3EN'
};

const img = (id, w = 1400) => `https://images.unsplash.com/${id}?auto=format&fit=crop&w=${w}&q=80`;
const FALLBACK_IMG = img('photo-1492144534655-ae79c964c9d7');

const VEHICLES = [
  {
    id: 'bmw-320d-m-sport-2021',
    make: 'BMW', model: '3 Series', variant: '320d M Sport Saloon Auto',
    year: 2021, price: 24995, mileage: 28450, fuel: 'Diesel', transmission: 'Automatic',
    body: 'Saloon', engine: '2.0L', bhp: 190, colour: 'Mineral Grey', doors: 4, owners: 1,
    mpg: 58.9, co2: 126, tax: '£190 / year', reg: 'March 2021 (21)', featured: true, badge: 'Just Arrived',
    images: [img('photo-1555215695-3004980ad54e'), img('photo-1580273916550-e323be2ae537'), img('photo-1609521263047-f8f205293f24')],
    features: ['M Sport body styling', 'BMW Live Cockpit Professional', 'Heated front sports seats', 'Reversing camera with Park Assist', 'Apple CarPlay & Android Auto', 'LED headlights', '18" M double-spoke alloys', 'Full BMW service history'],
    description: 'A superb one-owner 320d M Sport finished in Mineral Grey with black Vernasca leather. Supplied new by a BMW main dealer and maintained to schedule throughout, it comes with two keys, full documented history and the balance of BMW warranty. The 190bhp diesel pairs remarkable economy with genuine long-distance refinement.'
  },
  {
    id: 'audi-a4-avant-40-tfsi-s-line-2020',
    make: 'Audi', model: 'A4 Avant', variant: '40 TFSI S Line S Tronic',
    year: 2020, price: 22495, mileage: 31200, fuel: 'Petrol', transmission: 'Automatic',
    body: 'Estate', engine: '2.0L', bhp: 204, colour: 'Glacier White', doors: 5, owners: 2,
    mpg: 41.5, co2: 154, tax: '£190 / year', reg: 'September 2020 (70)', featured: true,
    images: [img('photo-1606664515524-ed2f786a0bd6'), img('photo-1502877338535-766e1452684a'), img('photo-1544636331-e26879cd4d9b')],
    features: ['S Line exterior & interior', 'Audi Virtual Cockpit', 'MMI Navigation Plus', 'Sports seats in leather/Alcantara', 'Electric tailgate', 'Front & rear parking sensors', 'Heated front seats', '18" alloy wheels'],
    description: 'Practical, refined and beautifully built, this A4 Avant S Line offers a huge boot, a 204bhp turbocharged petrol engine and the smooth seven-speed S Tronic gearbox. Full Audi service history, two keys and HPI clear.'
  },
  {
    id: 'mercedes-c220d-amg-line-2021',
    make: 'Mercedes-Benz', model: 'C-Class', variant: 'C220d AMG Line Premium 9G-Tronic',
    year: 2021, price: 26750, mileage: 22900, fuel: 'Diesel', transmission: 'Automatic',
    body: 'Saloon', engine: '2.0L', bhp: 194, colour: 'Obsidian Black', doors: 4, owners: 1,
    mpg: 60.1, co2: 123, tax: '£190 / year', reg: 'June 2021 (21)', featured: true,
    images: [img('photo-1617814076367-b759c7d7e738'), img('photo-1542362567-b07e54358753'), img('photo-1605559424843-9e4c228bf1c2')],
    features: ['AMG Line exterior styling', 'Premium package with panoramic roof', 'MBUX multimedia with 10.25" display', 'Burmester surround sound', 'Ambient lighting (64 colours)', 'Keyless-Go', 'Active parking assist with 360 camera', 'Mercedes-Benz service history'],
    description: 'The latest-generation C-Class in sought-after AMG Line Premium trim. One owner from new, Obsidian Black metallic with black Artico leather, and a full Mercedes-Benz service history. Exceptionally economical and packed with technology.'
  },
  {
    id: 'range-rover-evoque-d180-r-dynamic-se-2020',
    make: 'Land Rover', model: 'Range Rover Evoque', variant: 'D180 R-Dynamic SE Auto AWD',
    year: 2020, price: 29995, mileage: 34600, fuel: 'Diesel', transmission: 'Automatic',
    body: 'SUV', engine: '2.0L', bhp: 180, colour: 'Santorini Black', doors: 5, owners: 1,
    mpg: 42.7, co2: 173, tax: '£190 / year', reg: 'February 2020 (69)', featured: true, badge: 'Popular',
    images: [img('photo-1618843479313-40f8afb4b4d8'), img('photo-1552519507-da3b142c6e3d'), img('photo-1550355291-bbee04a92027')],
    features: ['R-Dynamic SE specification', 'Touch Pro Duo infotainment', 'Meridian sound system', 'Heated leather seats', '20" alloy wheels', 'Fixed panoramic roof', 'Terrain Response 2', '360 surround camera'],
    description: 'A stunning Evoque R-Dynamic SE in Santorini Black with Ebony leather. This all-wheel-drive D180 combines genuine off-road ability with the luxury and presence Range Rover is known for. One owner, full Land Rover history.'
  },
  {
    id: 'vw-golf-1-5-tsi-style-2022',
    make: 'Volkswagen', model: 'Golf', variant: '1.5 TSI 150 Style 5dr',
    year: 2022, price: 19995, mileage: 15300, fuel: 'Petrol', transmission: 'Manual',
    body: 'Hatchback', engine: '1.5L', bhp: 150, colour: 'Atlantic Blue', doors: 5, owners: 1,
    mpg: 51.4, co2: 125, tax: '£190 / year', reg: 'May 2022 (22)', featured: true,
    images: [img('photo-1590362891991-f776e747a588'), img('photo-1541899481282-d53bffe3c35d')],
    features: ['Digital Cockpit Pro', 'Discover Navigation 10" touchscreen', 'Adaptive cruise control', 'IQ.Light LED matrix headlights', 'Wireless App-Connect', 'Heated front seats', 'Front & rear parking sensors', 'Balance of VW warranty'],
    description: 'A very low mileage Mk8 Golf Style with the excellent 150bhp 1.5 TSI engine and six-speed manual gearbox. Immaculate throughout, with one owner and the remainder of the Volkswagen manufacturer warranty.'
  },
  {
    id: 'tesla-model-3-long-range-2021',
    make: 'Tesla', model: 'Model 3', variant: 'Long Range Dual Motor AWD',
    year: 2021, price: 27495, mileage: 26100, fuel: 'Electric', transmission: 'Automatic',
    body: 'Saloon', engine: 'Dual Motor', bhp: 346, colour: 'Pearl White', doors: 4, owners: 1,
    mpg: '360 mi range', co2: 0, tax: '£0 / year', reg: 'October 2021 (71)', featured: true,
    images: [img('photo-1560958089-b8a1929cea89'), img('photo-1549399542-7e3f8b79c341')],
    features: ['Long Range battery (WLTP 360 miles)', 'Dual motor all-wheel drive', 'Autopilot', '15" touchscreen', 'Premium interior & audio', 'Glass roof', 'Heated front & rear seats', 'Supercharger network access'],
    description: 'Zero-emission motoring with genuine long-range ability. This Model 3 Long Range offers 0-60 in 4.2 seconds, up to 360 miles per charge and over-the-air updates. Pearl White with black premium interior, one owner and a full charging kit included.'
  },
  {
    id: 'toyota-corolla-1-8-hybrid-design-2022',
    make: 'Toyota', model: 'Corolla', variant: '1.8 VVT-i Hybrid Design CVT',
    year: 2022, price: 18750, mileage: 19800, fuel: 'Hybrid', transmission: 'Automatic',
    body: 'Hatchback', engine: '1.8L Hybrid', bhp: 122, colour: 'Platinum White', doors: 5, owners: 1,
    mpg: 62.8, co2: 102, tax: '£180 / year', reg: 'March 2022 (22)', featured: false,
    images: [img('photo-1541899481282-d53bffe3c35d'), img('photo-1568605117036-5fe5e7bab0b7')],
    features: ['Toyota Safety Sense', '8" touchscreen with smartphone integration', 'Reversing camera', 'Heated front seats', 'LED headlights', '17" alloy wheels', 'Dual-zone climate control', 'Toyota hybrid battery warranty'],
    description: 'The self-charging Corolla Hybrid is one of the most dependable and economical cars on sale. This Design grade example has one owner, full Toyota history and the remainder of Toyota\'s manufacturer warranty.'
  },
  {
    id: 'porsche-macan-s-2019',
    make: 'Porsche', model: 'Macan', variant: 'S 3.0 V6 PDK',
    year: 2019, price: 38995, mileage: 41200, fuel: 'Petrol', transmission: 'Automatic',
    body: 'SUV', engine: '3.0L V6', bhp: 354, colour: 'Jet Black', doors: 5, owners: 2,
    mpg: 27.4, co2: 213, tax: '£415 / year', reg: 'July 2019 (19)', featured: true, badge: 'Performance',
    images: [img('photo-1503376780353-7e6692767b70'), img('photo-1525609004556-c46c7d6cf023'), img('photo-1502161254066-6c74afbf07aa')],
    features: ['Porsche Communication Management', 'BOSE surround sound', 'Sport Chrono package', 'Panoramic roof', '20" Macan Turbo alloys', 'Heated 14-way electric seats', 'Porsche Active Suspension Management', 'Full Porsche Centre history'],
    description: 'A superb Macan S with a highly desirable specification including Sport Chrono, panoramic roof and BOSE. The 354bhp twin-turbo V6 delivers real Porsche performance with everyday SUV practicality. Full Porsche Centre service history.'
  },
  {
    id: 'ford-mustang-5-0-gt-fastback-2019',
    make: 'Ford', model: 'Mustang', variant: '5.0 V8 GT Fastback Auto',
    year: 2019, price: 32995, mileage: 23400, fuel: 'Petrol', transmission: 'Automatic',
    body: 'Coupe', engine: '5.0L V8', bhp: 450, colour: 'Race Red', doors: 2, owners: 1,
    mpg: 23.7, co2: 270, tax: '£415 / year', reg: 'May 2019 (19)', featured: false,
    images: [img('photo-1494976388531-d1058494cdd8'), img('photo-1583121274602-3e2820c69888')],
    features: ['5.0 litre V8 with 450bhp', '10-speed automatic', 'Active valve performance exhaust', 'Recaro sports seats', 'MagneRide adaptive suspension', 'SYNC 3 with B&O sound', 'Rear camera & parking sensors', 'Launch control & line lock'],
    description: 'An iconic V8 Mustang GT in head-turning Race Red. One owner, low mileage and a full Ford service history. Active exhaust, MagneRide and Recaro seats make this a truly special performance coupe.'
  },
  {
    id: 'mini-cooper-s-sport-2020',
    make: 'MINI', model: 'Hatch', variant: 'Cooper S Sport 3dr Auto',
    year: 2020, price: 17995, mileage: 27600, fuel: 'Petrol', transmission: 'Automatic',
    body: 'Hatchback', engine: '2.0L', bhp: 178, colour: 'Chili Red', doors: 3, owners: 1,
    mpg: 44.1, co2: 146, tax: '£190 / year', reg: 'November 2020 (70)', featured: false,
    images: [img('photo-1617531653332-bd46c24f2068'), img('photo-1568605117036-5fe5e7bab0b7')],
    features: ['Sport pack with JCW styling', 'MINI Navigation system', 'LED headlights & union jack tail lights', 'Sports seats', '17" alloys', 'Rear parking sensors', 'Apple CarPlay', 'MINI TLC service pack'],
    description: 'A fun, fast and characterful Cooper S in Chili Red with contrasting black roof. One owner, full MINI service history and a great specification. Ideal as a stylish daily driver.'
  },
  {
    id: 'kia-sportage-1-6-t-gdi-gt-line-2022',
    make: 'Kia', model: 'Sportage', variant: '1.6 T-GDi GT-Line ISG',
    year: 2022, price: 24250, mileage: 17900, fuel: 'Petrol', transmission: 'Manual',
    body: 'SUV', engine: '1.6L', bhp: 150, colour: 'Penta Metal', doors: 5, owners: 1,
    mpg: 41.5, co2: 154, tax: '£190 / year', reg: 'August 2022 (22)', featured: false,
    images: [img('photo-1533473359331-0135ef1b58bf'), img('photo-1550355291-bbee04a92027')],
    features: ['12.3" curved dual display', 'GT-Line exterior styling', 'Reversing camera', 'Heated seats & steering wheel', 'Wireless phone charging', 'LED headlights', '19" alloy wheels', 'Balance of 7-year Kia warranty'],
    description: 'The all-new Sportage in GT-Line trim with the remainder of Kia\'s outstanding 7-year warranty. Low mileage, one owner and a fantastic level of standard equipment. A hugely practical family SUV.'
  },
  {
    id: 'mercedes-glc-220d-amg-line-2020',
    make: 'Mercedes-Benz', model: 'GLC', variant: 'GLC 220d 4Matic AMG Line Premium',
    year: 2020, price: 28495, mileage: 36800, fuel: 'Diesel', transmission: 'Automatic',
    body: 'SUV', engine: '2.0L', bhp: 194, colour: 'Selenite Grey', doors: 5, owners: 1,
    mpg: 47.1, co2: 158, tax: '£190 / year', reg: 'January 2020 (69)', featured: false,
    images: [img('photo-1619767886558-efdc259cde1a'), img('photo-1605559424843-9e4c228bf1c2')],
    features: ['AMG Line Premium package', '4Matic all-wheel drive', 'MBUX with augmented reality navigation', 'Panoramic sunroof', 'Electric memory heated seats', '20" AMG alloys', 'Keyless-Go', 'Full Mercedes-Benz history'],
    description: 'A luxurious and capable GLC 220d 4Matic in AMG Line Premium trim. Selenite Grey with black leather, panoramic roof and the latest MBUX system. One owner and full Mercedes-Benz service history.'
  }
];
