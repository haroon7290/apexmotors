/* Inventory page: filtering, sorting and rendering */

document.addEventListener('DOMContentLoaded', () => {
  const grid = document.getElementById('inventoryGrid');
  const count = document.getElementById('resultsCount');
  const form = document.getElementById('filtersForm');
  const sort = document.getElementById('sortBy');
  const reset = document.getElementById('resetFilters');
  const toggle = document.getElementById('filtersToggle');
  const filters = document.getElementById('filters');
  if (!grid || !form) return;

  const controls = {
    keyword: form.elements.keyword,
    make: form.elements.make,
    body: form.elements.body,
    fuel: form.elements.fuel,
    transmission: form.elements.transmission,
    minPrice: form.elements.minPrice,
    maxPrice: form.elements.maxPrice
  };

  // Populate selects from stock
  const fill = (select, values) => {
    [...new Set(values)].sort().forEach((val) => {
      select.insertAdjacentHTML('beforeend', `<option value="${escapeHtml(val)}">${escapeHtml(val)}</option>`);
    });
  };
  fill(controls.make, VEHICLES.map((v) => v.make));
  fill(controls.body, VEHICLES.map((v) => v.body));
  fill(controls.fuel, VEHICLES.map((v) => v.fuel));
  fill(controls.transmission, VEHICLES.map((v) => v.transmission));

  // Prefill from URL (hero search / deep links)
  const params = new URLSearchParams(window.location.search);
  Object.keys(controls).forEach((k) => {
    if (params.has(k) && controls[k]) controls[k].value = params.get(k);
  });
  if (params.has('sort') && sort) sort.value = params.get('sort');

  function getFiltered() {
    const kw = controls.keyword.value.trim().toLowerCase();
    const min = Number(controls.minPrice.value) || 0;
    const max = Number(controls.maxPrice.value) || Infinity;
    let list = VEHICLES.filter((v) => {
      if (controls.make.value && v.make !== controls.make.value) return false;
      if (controls.body.value && v.body !== controls.body.value) return false;
      if (controls.fuel.value && v.fuel !== controls.fuel.value) return false;
      if (controls.transmission.value && v.transmission !== controls.transmission.value) return false;
      if (v.price < min || v.price > max) return false;
      if (kw) {
        const hay = `${v.year} ${v.make} ${v.model} ${v.variant} ${v.colour} ${v.body} ${v.fuel}`.toLowerCase();
        if (!hay.includes(kw)) return false;
      }
      return true;
    });

    const sorters = {
      recommended: (a, b) => (b.featured === true) - (a.featured === true) || b.year - a.year,
      'price-asc': (a, b) => a.price - b.price,
      'price-desc': (a, b) => b.price - a.price,
      'mileage-asc': (a, b) => a.mileage - b.mileage,
      'year-desc': (a, b) => b.year - a.year || a.mileage - b.mileage
    };
    list.sort(sorters[sort?.value] || sorters.recommended);
    return list;
  }

  function syncUrl() {
    const p = new URLSearchParams();
    Object.entries(controls).forEach(([k, el]) => { if (el.value) p.set(k, el.value); });
    if (sort && sort.value !== 'recommended') p.set('sort', sort.value);
    const qs = p.toString();
    history.replaceState(null, '', window.location.pathname + (qs ? '?' + qs : ''));
  }

  function render() {
    const list = getFiltered();
    if (count) {
      count.innerHTML = `Showing <strong>${list.length}</strong> of <strong>${VEHICLES.length}</strong> vehicles`;
    }
    if (!list.length) {
      grid.innerHTML = `
        <div class="empty-state">
          <h3>No vehicles match your search</h3>
          <p>Try widening your filters, or tell us what you are looking for and we will source it for you.</p>
          <button type="button" class="btn btn-gold" id="emptyReset">Clear filters</button>
        </div>`;
      document.getElementById('emptyReset')?.addEventListener('click', clearAll);
    } else {
      renderVehicles(grid, list);
    }
    syncUrl();
  }

  function clearAll() {
    form.reset();
    if (sort) sort.value = 'recommended';
    render();
  }

  form.addEventListener('submit', (e) => { e.preventDefault(); render(); });
  form.addEventListener('change', render);
  controls.keyword.addEventListener('input', debounce(render, 250));
  sort?.addEventListener('change', render);
  reset?.addEventListener('click', clearAll);
  toggle?.addEventListener('click', () => {
    const open = filters.classList.toggle('open');
    toggle.setAttribute('aria-expanded', String(open));
    toggle.textContent = open ? 'Hide filters' : 'Show filters';
  });

  render();
});

function debounce(fn, wait) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), wait); };
}
