/* Vehicle details page */

document.addEventListener('DOMContentLoaded', () => {
  const root = document.getElementById('vehiclePage');
  if (!root) return;

  const id = new URLSearchParams(window.location.search).get('id');
  const v = getVehicle(id);

  if (!v) {
    root.innerHTML = `
      <div class="empty-state">
        <h3>Vehicle not found</h3>
        <p>This vehicle may have been sold or the link is incorrect. Browse our current stock instead.</p>
        <a href="inventory.html" class="btn btn-gold">View all vehicles</a>
      </div>`;
    return;
  }

  const title = `${v.year} ${v.make} ${v.model}`;
  document.title = `${title} ${v.variant} | ${DEALER.shortName}`;
  document.querySelector('meta[name="description"]')?.setAttribute('content', `${title} ${v.variant} for sale at ${DEALER.shortName}, Slough. ${fmtNumber(v.mileage)} miles, ${v.fuel}, ${v.transmission}. ${fmtPrice(v.price)}.`);

  const crumb = document.getElementById('crumbVehicle');
  if (crumb) crumb.textContent = title;

  const enquiryMsg = `Hi, I'm interested in the ${title} ${v.variant} (${fmtPrice(v.price)}). Please could you contact me with more information or to arrange a viewing?`;

  root.innerHTML = `
    <div class="vehicle-layout">
      <div>
        <div class="gallery-main">
          <img id="galleryMain" src="${v.images[0]}" alt="${escapeHtml(title)} main photo" onerror="this.onerror=null;this.src='${FALLBACK_IMG}'">
          ${v.badge ? `<span class="badge">${escapeHtml(v.badge)}</span>` : ''}
        </div>
        <div class="gallery-thumbs" id="galleryThumbs">
          ${v.images.map((src, i) => `<img src="${src}" alt="${escapeHtml(title)} photo ${i + 1}" class="${i === 0 ? 'active' : ''}" data-index="${i}" loading="lazy" onerror="this.onerror=null;this.src='${FALLBACK_IMG}'">`).join('')}
        </div>

        <section class="detail-block">
          <h2>Overview</h2>
          <p>${escapeHtml(v.description)}</p>
        </section>

        <section class="detail-block">
          <h2>Specifications</h2>
          <div class="spec-grid">
            ${spec('Mileage', fmtNumber(v.mileage) + ' miles')}
            ${spec('Fuel type', v.fuel)}
            ${spec('Transmission', v.transmission)}
            ${spec('Body type', v.body)}
            ${spec('Engine', v.engine)}
            ${spec('Power', v.bhp + ' bhp')}
            ${spec('Colour', v.colour)}
            ${spec('Doors', v.doors)}
            ${spec('Previous owners', v.owners)}
            ${spec(v.fuel === 'Electric' ? 'Range' : 'Economy (combined)', v.fuel === 'Electric' ? v.mpg : v.mpg + ' mpg')}
            ${spec('CO2 emissions', v.co2 + ' g/km')}
          </div>
        </section>

        <section class="detail-block">
          <h2>Features & equipment</h2>
          <ul class="features-list">${v.features.map((f) => `<li>${escapeHtml(f)}</li>`).join('')}</ul>
        </section>

        <section class="detail-block" id="enquire">
          <div class="enquiry-card">
            <span class="eyebrow">Enquire about this vehicle</span>
            <h2 style="border:0;padding:0;display:block;margin-bottom:1.5rem">Book a viewing or test drive</h2>
            <form id="vehicleEnquiry" class="form-grid">
              <div class="field"><label for="enqName">Full name</label><input id="enqName" name="name" type="text" required autocomplete="name"><span class="field-error">Please enter your name</span></div>
              <div class="field"><label for="enqPhone">Phone</label><input id="enqPhone" name="phone" type="tel" required autocomplete="tel"><span class="field-error">Please enter a valid phone number</span></div>
              <div class="field full"><label for="enqEmail">Email</label><input id="enqEmail" name="email" type="email" required autocomplete="email"><span class="field-error">Please enter a valid email address</span></div>
              <div class="field full"><label for="enqMessage">Message</label><textarea id="enqMessage" name="message" required>${escapeHtml(enquiryMsg)}</textarea><span class="field-error">Please enter a message</span></div>
              <div class="field full"><label class="consent"><input type="checkbox" name="consent" required> I agree to ${escapeHtml(DEALER.name)} contacting me about this enquiry.</label><span class="field-error">Please confirm you are happy for us to contact you</span></div>
              <div class="full"><button type="submit" class="btn btn-gold" data-label="Send enquiry">Send enquiry</button></div>
            </form>
            <div class="form-success" id="enquirySuccess"><strong>Thank you, your enquiry has been sent.</strong>One of our team will be in touch shortly. For an immediate response call <a href="${DEALER.phoneHref}">${DEALER.phone}</a>.</div>
          </div>
        </section>
      </div>

      <aside class="summary-card">
        <span class="eyebrow">${escapeHtml(v.reg)}</span>
        <h1>${escapeHtml(title)}</h1>
        <p class="variant">${escapeHtml(v.variant)}</p>
        <div class="summary-price">
          <div class="price">${fmtPrice(v.price)}</div>
          <div class="monthly"><strong>No admin fees</strong><span>Part exchange welcome</span></div>
        </div>
        <div class="summary-specs">
          <div><strong>${fmtNumber(v.mileage)} miles</strong>Mileage</div>
          <div><strong>${escapeHtml(v.fuel)}</strong>Fuel</div>
          <div><strong>${escapeHtml(v.transmission)}</strong>Transmission</div>
          <div><strong>${escapeHtml(v.body)}</strong>Body type</div>
        </div>
        <div class="summary-actions">
          <a href="${DEALER.phoneHref}" class="btn btn-gold btn-block">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.8.7 2.7a2 2 0 0 1-.5 2.1L8 9.8a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.7.7a2 2 0 0 1 1.9 2z"/></svg>
            Call ${DEALER.phone}
          </a>
          <a href="#enquire" class="btn btn-dark btn-block">Enquire / book test drive</a>
          <a href="${DEALER.whatsapp}?text=${encodeURIComponent(enquiryMsg)}" target="_blank" rel="noopener" class="btn btn-outline-dark btn-block">WhatsApp us</a>
        </div>
        <p class="summary-note">Price shown is the cash price and includes an HPI check, pre-delivery inspection and comprehensive warranty. Part exchange welcome and nationwide delivery available.</p>
      </aside>
    </div>`;

  // Gallery
  const main = document.getElementById('galleryMain');
  document.getElementById('galleryThumbs')?.addEventListener('click', (e) => {
    const t = e.target.closest('img[data-index]');
    if (!t) return;
    main.src = v.images[Number(t.dataset.index)];
    document.querySelectorAll('#galleryThumbs img').forEach((i) => i.classList.toggle('active', i === t));
  });

  // Enquiry form
  bindForm(document.getElementById('vehicleEnquiry'), () => {
    document.getElementById('enquirySuccess')?.classList.add('show');
  });

  // Similar vehicles
  const similar = VEHICLES.filter((s) => s.id !== v.id && (s.body === v.body || s.make === v.make)).slice(0, 3);
  const similarGrid = document.getElementById('similarVehicles');
  if (similarGrid) {
    if (similar.length) renderVehicles(similarGrid, similar);
    else similarGrid.closest('section')?.remove();
  }

  observeReveals();
});

function spec(label, value) {
  return `<div class="spec-item"><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)}</strong></div>`;
}
